export class UpdatePropertyDto {
  name?: string;
  organization_name?: string;
  location?: string;
  splitable?: boolean;
  isActive?: boolean;
}
