export class UpdatePropertyPartDto {
    part_name?: string;
    status?: "Available" | "Rented";
    isActive?: boolean;
  }
  