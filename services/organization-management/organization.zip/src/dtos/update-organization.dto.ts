export class UpdateOrganizationDto {
  name?: string;
  address?: string;
  email?: string;
  contactNo?: string;
  isActive?: boolean;
}
