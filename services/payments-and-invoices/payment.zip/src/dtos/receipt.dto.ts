export class ReceiptDto {
  receiptId!: string;
  invoiceId!: string;
  name!: string;
  serviceName!: string;
  amount!: number;
  date!: string;
  paymentMode!: string;
   orgName!:string ;
  orgAddress!: string ;
}
